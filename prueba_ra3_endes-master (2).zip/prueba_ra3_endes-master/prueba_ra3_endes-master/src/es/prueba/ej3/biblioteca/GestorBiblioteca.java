package es.prueba.ej3.biblioteca;
import java.util.ArrayList;
import java.util.List;




/**
 * Clase para gestionar una colección de libros en una biblioteca.
 * Permite realizar operaciones como agregar, buscar y eliminar libros de la colección.
 * 
 * @author ENDES
 * @version 1.0
 */
public class GestorBiblioteca {
    
    private List<Libro> biblioteca;
    private int cantidadLibros=0;
    /**
     * Constructor que inicializa la lista de libros.
     */
    public GestorBiblioteca() {
        biblioteca = new ArrayList<>();
    }

    /**
     * Agrega un libro a la biblioteca.
     * 
     * @param libro El libro a agregar.
     * @return true si el libro fue agregado con éxito, false si el libro ya existe.
     */
    public boolean agregarLibro(Libro libro) {
        biblioteca.add(libro);
    	return true;	
    }

    /**
     * Busca un libro por su título.
     * 
     * @param titulo El título del libro a buscar.
     * @return Un objeto {@code Libro} si se encuentra, {@code null} en caso contrario.
     */
    
    	 public Libro buscarLibro(String titulo) {
    	        for (int i = 0; i < biblioteca.size(); i++) {
    	        	Libro libro = biblioteca.get(i);
    	        	if (libro.getTitulo().equals(titulo)) {
    	                return libro;
    	        	}
    	        }
    	        return null;
    	 }

    /**
     * Elimina un libro de la biblioteca.
     * 
     * @param libro El libro a eliminar.
     * @return true si el libro fue eliminado con éxito, false si el libro no se encuentra en la biblioteca.
     */
    public boolean eliminarLibro(Libro libro) {
        biblioteca.remove(libro);
    	return false;
    }

    /**
     * Obtiene la lista de todos los libros en la biblioteca.
     * 
     * @return La lista de libros.
     */
    public List<Libro> obtenerTodosLosLibros() {
    	return biblioteca;
    }
}