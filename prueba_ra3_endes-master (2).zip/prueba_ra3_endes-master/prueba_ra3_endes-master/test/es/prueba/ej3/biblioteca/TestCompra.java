package es.prueba.ej3.biblioteca;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import es.prueba.ej2.clase_equivalencia.SistemaCompra;



class TestCompra {

	 @Test
	 @DisplayName("Test ejemplo de compra exitosa")
	    public void testCompraOk() {
	        SistemaCompra sc = new SistemaCompra();
	        String resultado = sc.realizarCompra("12345", 5, "Calle la rioja", "Tarjeta");
	        assertEquals("Compra exitosa", resultado);
	    }

	    @Test
	    @DisplayName("Test para cuando metes menos de 5 caracteres en codigo de producto")
	    public void testCodigoProductoInvalido() {
	        SistemaCompra sc = new SistemaCompra();
	        String resultado = sc.realizarCompra("999", 3, "Calle gelves", "PayPal");
	        assertEquals("Error: Código de producto inválido", resultado);
	    }

	    @Test
	    @DisplayName("Tes cantidad superior a 100")
	    public void testCantidadInvalida() {
	        SistemaCompra sc = new SistemaCompra();
	        String resultado = sc.realizarCompra("11111", 150, "calle ruiz", "Tarjeta");
	        assertEquals("Error: Cantidad inválida", resultado);
	    }
	    @Test
	    @DisplayName("Test para cuando la direccion de envio esta vacia")
	    public void testSinDireccion() {
	        SistemaCompra sc = new SistemaCompra();
	        String resultado = sc.realizarCompra("98765", 2, "", "PayPal");
	        assertEquals("Error: Dirección de envío inválida", resultado);
	    }

	    @Test
	    @DisplayName("Metodo de pago no vlaido")
	    public void testMetodoPagoInvalido() {
	        SistemaCompra sc = new SistemaCompra();
	        String resultado = sc.realizarCompra("54321", 1, "Avenida Principal, Tarjeta de credito", "Efectivo");
	        assertEquals("Error: Método de pago inválido", resultado);
	    }

}
