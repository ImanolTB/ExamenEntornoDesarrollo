package es.prueba.ej3.biblioteca;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import es.prueba.ej1.camino.Funciones;



class Test_Ej1 {

	@Test
    @DisplayName ("Prueba donde el elemento sí está presente")
    public void testBusquedaElementoPresente() {
        Funciones busqueda = new Funciones();
        int[] arr = {1, 2, 3, 4, 5};
        int resultado = busqueda.busquedaSecuencial(arr, 3);
        assertEquals(2, resultado); 
    }
    @Test
    @DisplayName (" Prueba donde el elemento no está presente")
    public void testBusquedaElementoNoPresente() {
        Funciones busqueda = new Funciones();
        int[] arr = {1, 2, 3, 4, 5};
        int resultado = busqueda.busquedaSecuencial(arr, 6);
        assertEquals(-1, resultado); 
    }
    @Test
    @DisplayName (" Prueba donde el elemento está presente pero no en el medio")
    public void testBusquedaElementoPresentesNoEnMedio() {
        Funciones busqueda = new Funciones();
        int[] arr = {1, 2, 3, 4, 5};
        int resultado = busqueda.busquedaSecuencial(arr, 2);
        assertEquals(1, resultado); 
    }

}
